import joblib, cloudpickle

pipe = joblib.load("model.joblib")
with open("model.cpkl", "wb") as f:
    cloudpickle.dump(pipe, f)

print("✅ Conversion terminée : model.cpkl créé")
