# Student Habits → Exam Score — API (final)

Ce package contient votre modèle déjà inclus et une API FastAPI.
Le chargement privilégie `model.cpkl` (cloudpickle) s'il existe, sinon `model.joblib`.

## Lancer en local (Windows conseillé: 1 worker)
```bash
pip install -r requirements.txt
# (optionnel) convertir en cloudpickle une fois:
python convert_model.py
uvicorn app:app --host 0.0.0.0 --port 8000 --workers 1
```

Swagger UI: http://localhost:8000/docs

## Docker
```bash
# (optionnel) python convert_model.py  # crée model.cpkl
docker build -t student-habits-api:final .
docker run -p 8000:8000 --name habits student-habits-api:final
```
