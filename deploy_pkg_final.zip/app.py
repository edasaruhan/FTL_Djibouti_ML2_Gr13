import os
import json
import math
import pandas as pd
from fastapi import FastAPI
from pydantic import BaseModel, conint, confloat

# Charger le modèle: priorité à cloudpickle si model.cpkl existe
pipe = None
if os.path.exists("model.cpkl"):
    import cloudpickle
    with open("model.cpkl", "rb") as f:
        pipe = cloudpickle.load(f)
else:
    import joblib
    pipe = joblib.load("model.joblib")

# Charger les meta si présents (optionnel)
FEATURE_NAMES = None
try:
    with open("feature_names.json", "r", encoding="utf-8") as f:
        FEATURE_NAMES = json.load(f)
except Exception:
    FEATURE_NAMES = None

NUMERIC_BASE = [
    "study_hours_per_day","social_media_hours","netflix_hours",
    "attendance_percentage","sleep_hours","exercise_frequency",
    "mental_health_rating","age"
]

def add_lifestyle_index(df: pd.DataFrame) -> pd.DataFrame:
    # Calcule lifestyle_index si la colonne n'existe pas déjà
    if "lifestyle_index" in df.columns:
        return df
    # z-scores basés sur valeurs d'entrée (fallback simple);
    # en production, l'idéal est d'utiliser les stats du fit.
    tmp = df[NUMERIC_BASE].astype(float)
    # Eviter division par 0
    std = tmp.std(ddof=0).replace(0, 1.0)
    z = (tmp - tmp.mean()) / std
    lifestyle = (
        + 1.2*z["study_hours_per_day"]
        - 0.6*z["social_media_hours"]
        - 0.6*z["netflix_hours"]
        + 0.8*z["attendance_percentage"]
        + 0.5*z["sleep_hours"]
        + 0.6*z["exercise_frequency"]
        + 0.8*z["mental_health_rating"]
        - 0.1*z["age"]
    )
    df = df.copy()
    df["lifestyle_index"] = lifestyle
    return df

app = FastAPI(title="Student Habits → Exam Score API", version="2.0")

class StudentInput(BaseModel):
    gender: str
    part_time_job: str
    diet_quality: str
    parental_education_level: str
    internet_quality: str
    extracurricular_participation: str
    study_hours_per_day: confloat(ge=0, le=24)
    social_media_hours: confloat(ge=0, le=24)
    netflix_hours: confloat(ge=0, le=24)
    attendance_percentage: confloat(ge=0, le=100)
    sleep_hours: confloat(ge=0, le=24)
    exercise_frequency: conint(ge=0, le=14)
    mental_health_rating: conint(ge=0, le=10)
    age: conint(ge=15, le=80)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict")
def predict(inp: StudentInput):
    X = pd.DataFrame([inp.dict()])
    # Ajouter lifestyle_index si le modèle l'attend
    need_lifestyle = True
    if FEATURE_NAMES and isinstance(FEATURE_NAMES, list):
        need_lifestyle = any("lifestyle_index" in str(n) for n in FEATURE_NAMES)
    if need_lifestyle:
        X = add_lifestyle_index(X)
    yhat = pipe.predict(X)[0]
    return {"exam_score_pred": float(yhat)}
